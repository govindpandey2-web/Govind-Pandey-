package com.advocate.diary;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/** HTML में window.WebToApk नाम से मिलता है: Icon बदलना, File save, Print */
public class AppBridge {
    private static final String[] NAMES = {"default", "gold", "green", "red"};
    private static final String[] ALIASES = {".IconDefault", ".IconGold", ".IconGreen", ".IconRed"};
    private final Activity act;
    private final WebView web;

    public AppBridge(Activity a, WebView w) { act = a; web = w; }

    @JavascriptInterface
    public String getAvailableIcons() {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < NAMES.length; i++) {
            if (i > 0) sb.append(",");
            sb.append("\"").append(NAMES[i]).append("\"");
        }
        return sb.append("]").toString();
    }

    @JavascriptInterface
    public String getAppIcon() {
        SharedPreferences sp = act.getSharedPreferences("adv_prefs", Context.MODE_PRIVATE);
        return sp.getString("icon", "default");
    }

    @JavascriptInterface
    public boolean setAppIcon(String name) {
        int idx = -1;
        for (int i = 0; i < NAMES.length; i++) if (NAMES[i].equals(name)) idx = i;
        if (idx < 0) return false;
        try {
            PackageManager pm = act.getPackageManager();
            String pkg = act.getPackageName();
            // पहले नया चालू करें, फिर बाकी बंद करें
            pm.setComponentEnabledSetting(new ComponentName(pkg, pkg + ALIASES[idx]),
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
            for (int i = 0; i < ALIASES.length; i++) {
                if (i == idx) continue;
                pm.setComponentEnabledSetting(new ComponentName(pkg, pkg + ALIASES[i]),
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
            }
            act.getSharedPreferences("adv_prefs", Context.MODE_PRIVATE).edit().putString("icon", name).apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface public void splashReady() { }
    @JavascriptInterface public void splashHold() { }

    @JavascriptInterface
    public void toast(final String msg) {
        act.runOnUiThread(new Runnable() { public void run() { Toast.makeText(act, msg, Toast.LENGTH_LONG).show(); } });
    }

    /** Backup / export file को फ़ोन के Downloads में save करता है */
    @JavascriptInterface
    public boolean saveFile(String name, String mime, String base64) {
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            if (name == null || name.length() == 0) name = "advocate_file";
            name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
            String where;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                cv.put(MediaStore.Downloads.MIME_TYPE, (mime == null || mime.length() == 0) ? "application/octet-stream" : mime);
                cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = act.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                OutputStream os = act.getContentResolver().openOutputStream(uri);
                os.write(data);
                os.close();
                where = "Downloads";
            } else {
                File dir = act.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                File f = new File(dir, name);
                FileOutputStream os = new FileOutputStream(f);
                os.write(data);
                os.close();
                where = f.getAbsolutePath();
            }
            toast("✅ File save हो गई: " + name + " (" + where + ")");
            return true;
        } catch (Exception e) {
            toast("❌ File save नहीं हुई: " + e.getMessage());
            return false;
        }
    }

    @JavascriptInterface
    public void print() {
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    PrintManager pm = (PrintManager) act.getSystemService(Context.PRINT_SERVICE);
                    pm.print("Advocate Diary", web.createPrintDocumentAdapter("Advocate Diary"), new PrintAttributes.Builder().build());
                } catch (Exception e) { }
            }
        });
    }
}
