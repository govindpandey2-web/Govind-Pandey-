package com.advocate.diary;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String id = intent.getStringExtra("id");
        post(ctx, intent.getStringExtra("title"), intent.getStringExtra("body"), id == null ? 1 : id.hashCode());
    }

    static void post(Context ctx, String title, String body, int nid) {
        NotifyBridge.createChannel(ctx);
        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pi = PendingIntent.getActivity(ctx, 0, open, flags);
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) nb = new Notification.Builder(ctx, NotifyBridge.CH);
        else nb = new Notification.Builder(ctx).setPriority(Notification.PRIORITY_HIGH);
        String t = title == null ? "Advocate Diary" : title;
        String b = body == null ? "" : body;
        nb.setSmallIcon(android.R.drawable.ic_popup_reminder)
          .setContentTitle(t)
          .setContentText(b)
          .setStyle(new Notification.BigTextStyle().bigText(b))
          .setAutoCancel(true)
          .setContentIntent(pi)
          .setVisibility(Notification.VISIBILITY_PUBLIC);
        ((NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify(nid, nb.build());
    }
}
