package com.advocate.diary;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.json.JSONObject;
import java.util.Iterator;

/** फ़ोन restart या app update के बाद सारे alarm दोबारा लगाता है */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            JSONObject o = new JSONObject(ctx.getSharedPreferences(NotifyBridge.PREFS, Context.MODE_PRIVATE).getString("all", "{}"));
            long now = System.currentTimeMillis();
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String id = it.next();
                JSONObject v = o.getJSONObject(id);
                if (v.getLong("at") > now) NotifyBridge.setAlarm(ctx, id, v.getLong("at"), v.getString("t"), v.getString("b"));
            }
        } catch (Exception e) { }
    }
}
