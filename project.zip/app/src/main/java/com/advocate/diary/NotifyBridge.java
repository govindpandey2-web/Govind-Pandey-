package com.advocate.diary;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.webkit.JavascriptInterface;
import org.json.JSONObject;
import java.util.Iterator;

/** HTML में window.AndroidNotify नाम से मिलता है */
public class NotifyBridge {
    static final String CH = "advdiary_cases";
    static final String PREFS = "adv_alarms";
    private final Activity act;

    public NotifyBridge(Activity a) {
        act = a;
        createChannel(a);
    }

    static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "Case Reminders", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("अगली पेशी के Reminder");
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    @JavascriptInterface
    public void requestPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && act.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            act.runOnUiThread(new Runnable() {
                public void run() {
                    act.requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 101);
                }
            });
        }
    }

    @JavascriptInterface
    public void show(String title, String body, String tag) {
        AlarmReceiver.post(act, title, body, tag == null ? 0 : tag.hashCode());
    }

    @JavascriptInterface
    public void schedule(String id, String whenMillis, String title, String body) {
        try {
            long at = Long.parseLong(whenMillis);
            setAlarm(act, id, at, title, body);
            SharedPreferences sp = act.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONObject o = new JSONObject(sp.getString("all", "{}"));
            JSONObject v = new JSONObject();
            v.put("at", at);
            v.put("t", title);
            v.put("b", body);
            o.put(id, v);
            sp.edit().putString("all", o.toString()).apply();
        } catch (Exception e) { }
    }

    @JavascriptInterface
    public void cancelAll() {
        try {
            SharedPreferences sp = act.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONObject o = new JSONObject(sp.getString("all", "{}"));
            AlarmManager am = (AlarmManager) act.getSystemService(Context.ALARM_SERVICE);
            Iterator<String> it = o.keys();
            while (it.hasNext()) am.cancel(pending(act, it.next(), "", ""));
            sp.edit().putString("all", "{}").apply();
        } catch (Exception e) { }
    }

    static PendingIntent pending(Context c, String id, String t, String b) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction("com.advocate.diary.ALARM");
        i.putExtra("id", id);
        i.putExtra("title", t);
        i.putExtra("body", b);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(c, id.hashCode(), i, flags);
    }

    static void setAlarm(Context c, String id, long at, String t, String b) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pending(c, id, t, b);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else {
                am.set(AlarmManager.RTC_WAKEUP, at, pi);
            }
        } catch (SecurityException e) {
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.set(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }
}
